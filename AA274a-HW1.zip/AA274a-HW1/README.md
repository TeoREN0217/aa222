# Pinciples of Robot Autonomy I HW1
Homework 1 code for Principles of Robot Autonomy I
## Dependencies
Python package dependencies for this assignment are listed in the `requirements.txt` file and can be automatically installed by
```
pip install -r requirements.txt
```

## AA174A / CS137A / EE160A (Undergrad Section)
Please ignore `P4_trajectory_optimization`.
